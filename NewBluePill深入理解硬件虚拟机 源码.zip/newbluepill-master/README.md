# newbluepill
new blue pill
